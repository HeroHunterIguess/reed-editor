### Editng functions ###

# Handle hitting enter for a new line
def new_line(buffer, cursor_location):
    # Try-except incase the line is empty
    try:
        len(buffer[cursor_location[0]])

        # Split line into parts to seperate them
        current_line = buffer[cursor_location[0]]
        left = current_line[:cursor_location[1]]
        right = current_line[cursor_location[1]:]

        # Split the two onto different lines
        buffer[cursor_location[0]] = left
        buffer.insert(cursor_location[0] + 1, right)
    except IndexError:
        # If the line is empty then create new empty line
        buffer.append([])

    # Fix cursor location
    cursor_location[0] += 1
    cursor_location[1] = 0

    return buffer, cursor_location

# Handle backspacing cases
def backspace(buffer, cursor_location, holding_ctrl):
    line = buffer[cursor_location[0]]
    removed_space = False

    # Delete whole word if holding control
    if holding_ctrl:
        moves = 0

        # If youre on a space, just delete that space
        if buffer[cursor_location[0]][cursor_location[1] - 1] == " ":
            del buffer[cursor_location[0]][cursor_location[1] - 1]
            cursor_location[1] -= 1
            removed_space = True
        
        # Delete whole word
        if not removed_space:
            for char in reversed(line[:cursor_location[1]]):
                if char != " ":
                    moves += 1
                else:
                    break

            # Delete characters
            start = cursor_location[1] - moves
            del line[start:cursor_location[1]]

            cursor_location[1] = start
    else:
        # Delete previous character in standard usage
        if cursor_location[1] > 0:
            buffer[cursor_location[0]].pop(cursor_location[1] - 1)
            cursor_location[1] -= 1
        
        # If line is empty then remove the \n before
        elif cursor_location[0] > 0:
            previous_line_len = len(buffer[cursor_location[0] - 1])
            
            # Try-except to prevent index overflow with empty line
            try:
                len(buffer[cursor_location[0]])
                # Move current lines characters to the line above
                buffer[cursor_location[0] - 1].extend(buffer[cursor_location[0]])
            
                # Remove current line
                buffer.pop(cursor_location[0])
            except IndexError:
                pass

            # Fix cursor location
            cursor_location[0] -= 1
            cursor_location[1] = previous_line_len
    
    return buffer, cursor_location

# Handle hitting delete key 
# Currently cannot delete on end of line to merge with next 
def delete(buffer, cursor_location, holding_ctrl):
    line = buffer[cursor_location[0]]

    # If holding control delete whole word
    if holding_ctrl:
        moves = 0

        # If youre on a space, delete only that space
        if cursor_location[1] < len(line) and line[cursor_location[1]] == " ":
            del line[cursor_location[1]]
        
        else: 
            for char in line[cursor_location[1]:]:
                if char != " ":
                    moves += 1
                else:
                    break   
            
            # Delete word
            del line[cursor_location[1]:cursor_location[1] + moves]

    else:
        # Standard single character delete
        if cursor_location[1] < len(line):
            buffer[cursor_location[0]].pop(cursor_location[1])

    return buffer, cursor_location

# insert given unicode character
def insert_character(buffer, cursor_location, event):
    buffer[cursor_location[0]].insert(cursor_location[1], event.unicode)
    cursor_location[1] += 1

    return buffer, cursor_location
